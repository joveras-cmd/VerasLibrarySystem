
#include <iostream>
#include <string>
#include <vector>
#include <fstream>
using namespace std;

class Book {
    private:
    	string title;
    	string author;
    	string isbn;
    	bool available;
    
    public:
    	Book(string t, string a, string i, bool avail = true) {
    		title = t;
    		author = a;
    		isbn = i;
    		available = avail;
    	}
    
    	string getTitle() {
    		return title;
    	}
    	string getAuthor() {
    		return author;
    	}
    	string getISBN() {
    		return isbn;
    	}
    	bool isAvailable() {
    		return available;
    	}
    
    	void setAvailability(bool avail) {
    		available = avail;
    	}
    
    	string toString() {
    		return title + ";" + author + ";" + isbn + ";" + (available ? "1" : "0");
    	}
};

class User {
    private:
    	string userID;
    	string name;
    
    public:
    	User(string id, string n) {
    		userID = id;
    		name = n;
    	}
    
    	string getUserID() {
    		return userID;
    	}
    	string getName() {
    		return name;
    	}
    
    	string toString() {
    		return userID + ";" + name;
    	}
};

class Library {
    private:
    	vector<Book*> books;
    	vector<User*> users;
    
    public:
    	~Library() {
    		// free allocated memory
    		for (Book* b : books) delete b;
    		for (User* u : users) delete u;
    	}
    
    	// books
    	void addBook(string title, string author, string isbn) {
    		for (Book* b : books) {
    			if (b->getISBN() == isbn) {
    				cout << "b Book already exists.\n";
    				return;
    			}
    		}
    		books.push_back(new Book(title, author, isbn));
    		cout << "b Book \"" << title << "\" added.\n";
    	}
    
    	void removeBook(string isbn) {
    		for (int i = 0; i < books.size(); i++) {
    			if (books[i]->getISBN() == isbn) {
    				cout << "b Book \"" << books[i]->getTitle() << "\" removed.\n";
    				delete books[i];
    				books.erase(books.begin() + i);
    				return;
    			}
    		}
    		cout << "b Book not found.\n";
    	}
    
    	void displayBooks() {
    		if (books.empty()) {
    			cout << "No books available.\n";
    			return;
    		}
    		cout << "\n=== Books ===\n";
    		for (Book* b : books) {
    			cout << "Title: " << b->getTitle()
    			     << ", Author: " << b->getAuthor()
    			     << ", ISBN: " << b->getISBN()
    			     << ", Status: " << (b->isAvailable() ? "Available" : "Borrowed") << endl;
    		}
    	}
    
    	// users
    	void registerUser(string id, string name) {
    		for (User* u : users) {
    			if (u->getUserID() == id) {
    				cout << "b User already exists.\n";
    				return;
    			}
    		}
    		users.push_back(new User(id, name));
    		cout << "b User \"" << name << "\" registered.\n";
    	}
    
    	void removeUser(string id) {
    		for (int i = 0; i < users.size(); i++) {
    			if (users[i]->getUserID() == id) {
    				cout << "b User \"" << users[i]->getName() << "\" removed.\n";
    				delete users[i];
    				users.erase(users.begin() + i);
    				return;
    			}
    		}
    		cout << "b User not found.\n";
    	}
    
    	void displayUsers() {
    		if (users.empty()) {
    			cout << "No users registered.\n";
    			return;
    		}
    		cout << "\n=== Users ===\n";
    		for (User* u : users) {
    			cout << "ID: " << u->getUserID()
    			     << ", Name: " << u->getName() << endl;
    		}
    	}
    
    	// borrow & return
    	void borrowBook(string isbn, string userID) {
    		Book* bookPtr = NULL;
    		User* userPtr = NULL;
    
    		for (Book* b : books) {
    			if (b->getISBN() == isbn) {
    				bookPtr = b;
    				break;
    			}
    		}
    		for (User* u : users) {
    			if (u->getUserID() == userID) {
    				userPtr = u;
    				break;
    			}
    		}
    
    		if (!bookPtr) {
    			cout << "b Book not found.\n";
    			return;
    		}
    		if (!userPtr) {
    			cout << "b User not found.\n";
    			return;
    		}
    		if (!bookPtr->isAvailable()) {
    			cout << "b Book is already borrowed.\n";
    			return;
    		}
    
    		bookPtr->setAvailability(false);
    		saveBorrow(isbn, userID);
    		cout << "b " << userPtr->getName() << " borrowed \"" << bookPtr->getTitle() << "\".\n";
    	}
    
    	void returnBook(string isbn, string userID) {
    		Book* bookPtr = NULL;
    		for (Book* b : books) {
    			if (b->getISBN() == isbn) {
    				bookPtr = b;
    				break;
    			}
    		}
    		if (!bookPtr) {
    			cout << "b Book not found.\n";
    			return;
    		}
    		if (bookPtr->isAvailable()) {
    			cout << "b This book wasn't borrowed.\n";
    			return;
    		}
    
    		bookPtr->setAvailability(true);
    		removeBorrow(isbn, userID);
    		cout << "b Book \"" << bookPtr->getTitle() << "\" returned.\n";
    	}
    
    	// data persistence
    	void saveData() {
    		ofstream fout("books.txt");
    		for (Book* b : books) fout << b->toString() << endl;
    		fout.close();
    
    		fout.open("users.txt");
    		for (User* u : users) fout << u->toString() << endl;
    		fout.close();
    	}
    
    	void loadData() {
    		for (Book* b : books) delete b;
    		for (User* u : users) delete u;
    		books.clear();
    		users.clear();
    
    		ifstream fin("books.txt");
    		string line;
    		while (getline(fin, line)) {
    			if (line.empty()) continue;
    			size_t p1 = line.find(';');
    			size_t p2 = line.find(';', p1 + 1);
    			size_t p3 = line.find(';', p2 + 1);
    			string t = line.substr(0, p1);
    			string a = line.substr(p1 + 1, p2 - p1 - 1);
    			string i = line.substr(p2 + 1, p3 - p2 - 1);
    			bool avail = (line.substr(p3 + 1) == "1");
    			books.push_back(new Book(t, a, i, avail));
    		}
    		fin.close();
    
    		fin.open("users.txt");
    		while (getline(fin, line)) {
    			if (line.empty()) continue;
    			size_t p1 = line.find(';');
    			string id = line.substr(0, p1);
    			string n = line.substr(p1 + 1);
    			users.push_back(new User(id, n));
    		}
    		fin.close();
    	}
    
    	// for borrow file
    	void saveBorrow(string isbn, string userID) {
    		ofstream fout("borrows.txt", ios::app);
    		fout << isbn << ";" << userID << endl;
    		fout.close();
    	}
    
    	void removeBorrow(string isbn, string userID) {
    		ifstream fin("borrows.txt");
    		vector<string> lines;
    		string line;
    		while (getline(fin, line)) {
    			if (line != isbn + ";" + userID) {
    				lines.push_back(line);
    			}
    		}
    		fin.close();
    		ofstream fout("borrows.txt");
    		for (string l : lines) fout << l << endl;
    		fout.close();
    	}
    
    	void displayBorrows() {
    		ifstream fin("borrows.txt");
    		string line;
    		cout << "\n=== Borrow Records ===\n";
    		while (getline(fin, line)) {
    			cout << line << endl;
    		}
    		fin.close();
    	}
};

int main() {
	Library lib;
	lib.loadData();

	int choice;
	string id, name, title, author, isbn;

	while (true) {
		cout << "\n=== Library Menu ===\n";
		cout << "1. Register User\n";
		cout << "2. Remove User\n";
		cout << "3. Display Users\n";
		cout << "4. Add Book\n";
		cout << "5. Remove Book\n";
		cout << "6. Display Books\n";
		cout << "7. Borrow Book\n";
		cout << "8. Return Book\n";
		cout << "9. Display Borrow Records\n";
		cout << "0. Exit\n";
		cout << "Choice: ";
		cin >> choice;

		if (choice == 0) {
			lib.saveData();
			cout << "p> Data saved. Exiting...\n";
			break;
		}

		switch (choice) {
		case 1:
			cout << "Enter User ID: ";
			cin >> id;
			cin.ignore();
			cout << "Enter Name: ";
			getline(cin, name);
			lib.registerUser(id, name);
			break;

		case 2:
			cout << "Enter User ID to remove: ";
			cin >> id;
			lib.removeUser(id);
			break;

		case 3:
			lib.displayUsers();
			break;

		case 4:
			cin.ignore();
			cout << "Enter Title: ";
			getline(cin, title);
			cout << "Enter Author: ";
			getline(cin, author);
			cout << "Enter ISBN: ";
			getline(cin, isbn);
			lib.addBook(title, author, isbn);
			break;

		case 5:
			cout << "Enter ISBN to remove: ";
			cin >> isbn;
			lib.removeBook(isbn);
			break;

		case 6:
			lib.displayBooks();
			break;

		case 7:
			cout << "Enter ISBN to borrow: ";
			cin >> isbn;
			cout << "Enter User ID: ";
			cin >> id;
			lib.borrowBook(isbn, id);
			break;

		case 8:
			cout << "Enter ISBN to return: ";
			cin >> isbn;
			cout << "Enter User ID: ";
			cin >> id;
			lib.returnBook(isbn, id);
			break;

		case 9:
			lib.displayBorrows();
			break;

		default:
			cout << "b Invalid choice.\n";
		}
	}
	return 0;
};



